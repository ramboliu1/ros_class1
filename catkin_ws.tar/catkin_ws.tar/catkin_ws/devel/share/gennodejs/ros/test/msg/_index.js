
"use strict";

let num = require('./num.js');

module.exports = {
  num: num,
};
